Generated reports and plots will appear here after running src/train.py.
