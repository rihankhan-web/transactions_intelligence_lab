from pathlib import Path
import joblib
import pandas as pd
import streamlit as st

ROOT = Path(__file__).resolve().parent
DATA = ROOT / "data" / "transactions_synthetic.csv"
MODEL = ROOT / "models" / "best_model.joblib"

st.set_page_config(page_title="Transaction Intelligence Lab", page_icon="🔎", layout="wide")
st.title("🔎 Transaction Intelligence Lab")
st.caption("B.Tech CSE (AI/ML) portfolio demo • synthetic data only • not a real fraud detection service")

df = pd.read_csv(DATA)
with st.sidebar:
    st.header("Explore dataset")
    categories = st.multiselect("Merchant category", sorted(df["merchant_category"].unique()),
                                default=sorted(df["merchant_category"].unique()))
    amount_range = st.slider("Transaction amount (₹)", 0, int(df["amount_inr"].max()),
                              (0, int(df["amount_inr"].quantile(.99))), step=500)
    show_label = st.selectbox("Dataset label", ["All", "Normal-labelled", "Fraud-labelled"])

view = df[df["merchant_category"].isin(categories)]
view = view[view["amount_inr"].between(*amount_range)]
if show_label == "Normal-labelled":
    view = view[view["is_fraud"] == 0]
elif show_label == "Fraud-labelled":
    view = view[view["is_fraud"] == 1]

c1, c2, c3 = st.columns(3)
c1.metric("Filtered transactions", f"{len(view):,}")
c2.metric("Transaction value", f"₹{view['amount_inr'].sum():,.0f}")
c3.metric("Positive-label rate", f"{view['is_fraud'].mean()*100:.2f}%" if len(view) else "N/A")

left, right = st.columns(2)
with left:
    st.subheader("Transactions by category")
    st.bar_chart(view["merchant_category"].value_counts())
with right:
    st.subheader("Label rate by category (%)")
    if len(view):
        st.bar_chart(view.groupby("merchant_category")["is_fraud"].mean().mul(100))
st.subheader("Sample rows")
st.dataframe(view.head(150), use_container_width=True)

st.divider()
st.subheader("Try a single synthetic transaction")
with st.form("predict_form"):
    a, b, c = st.columns(3)
    amount = a.number_input("Amount (₹)", min_value=0.0, value=1500.0, step=100.0)
    hour = b.slider("Hour (0–23)", 0, 23, 21)
    merchant = c.selectbox("Merchant category", sorted(df["merchant_category"].unique()))
    d, e, f = st.columns(3)
    weekend = d.selectbox("Weekend?", [0, 1], format_func=lambda x: "Yes" if x else "No")
    new_device = e.selectbox("New device?", [0, 1], format_func=lambda x: "Yes" if x else "No")
    mismatch = f.selectbox("Location mismatch?", [0, 1], format_func=lambda x: "Yes" if x else "No")
    failed = st.slider("Failed attempts", 0, 7, 0)
    submitted = st.form_submit_button("Score example")
if submitted:
    if not MODEL.exists():
        st.error("Model file not found. First run: python src/train.py")
    else:
        model = joblib.load(MODEL)
        sample = pd.DataFrame([{
            "amount_inr": amount, "hour": hour, "merchant_category": merchant,
            "is_weekend": weekend, "new_device": new_device,
            "location_mismatch": mismatch, "failed_attempts": failed
        }])
        score = float(model.predict_proba(sample)[0, 1])
        st.metric("Model score for synthetic example", f"{score*100:.1f}%")
        st.info("This score is only a model output on synthetic training data. It is not a calibrated real-world probability and must not be used to approve, block, or investigate real transactions.")

st.warning("All dataset labels are simulated. This is a learning demo, not a real financial security product.")
