# Transaction Intelligence Lab
### B.Tech CSE (AI/ML) — Data Analysis + Classical ML + Interactive Dashboard

**Scope:** a portfolio/academic demonstration using synthetic UPI-style transactions. It is not a production fraud detector. All rows and labels are generated for learning; no real banking data is included.

## Why this is suitable for an AI/ML student
- Exploratory data analysis (EDA) and grouped summaries
- Data validation and duplicate removal
- Train/test split with stratification
- Preprocessing pipeline: median imputation, scaling, one-hot encoding
- Baseline comparison: Logistic Regression vs Random Forest
- Metrics beyond accuracy: precision, recall, F1, ROC-AUC, Average Precision, Brier score
- Confusion matrix, precision-recall curve, permutation feature importance
- Saved scikit-learn pipeline and Streamlit dashboard

## Folder structure
- `data/transactions_synthetic.csv` — 8,000 synthetic transactions
- `src/train.py` — full analysis/training pipeline
- `app.py` — interactive Streamlit dashboard and example scorer
- `models/` — trained model created by training script
- `reports/` — charts, CSV summaries, metrics report generated on run
- `requirements.txt` — dependencies

## Setup
Python 3.10+ recommended. From this folder:

```bash
python -m venv .venv
```
Activate it:
- Windows PowerShell: `.venv\Scripts\Activate.ps1`
- Windows CMD: `.venv\Scripts\activate.bat`
- macOS/Linux: `source .venv/bin/activate`

Then install:
```bash
pip install -r requirements.txt
```

Train and generate reports:
```bash
python src/train.py
```

Launch dashboard (after training):
```bash
streamlit run app.py
```

## Suggested academic report
1. Abstract
2. Problem statement and objectives
3. Dataset description and synthetic-data caveat
4. Data cleaning and EDA
5. Feature engineering / preprocessing
6. Methodology and model comparison
7. Evaluation: confusion matrix, precision/recall, average precision
8. Feature importance and interpretation
9. Limitations, ethics, and future work
10. Conclusion

## Important limitations / ethics
- The labels are generated using a known synthetic rule. Model performance here is not evidence of real-world performance.
- `model score` in the dashboard is not a calibrated risk probability.
- Never use this project to make real payment decisions, profile people, or label actual customers.
- For a genuine research extension, use a public, appropriately licensed, anonymized benchmark dataset; document its provenance and check class imbalance, leakage, fairness, and drift.

## Viva preparation
**Why not accuracy alone?** In imbalanced classification, a model can get high accuracy by predicting the majority class; precision, recall, F1 and precision-recall analysis show more.

**Why stratified split?** It keeps the positive-label proportion approximately similar across train and test sets.

**Why a pipeline?** It keeps preprocessing and model steps together and helps avoid fitting preprocessing on the held-out test set.

**Why compare Logistic Regression and Random Forest?** Logistic Regression is a simple baseline; Random Forest can model nonlinear interactions. Neither is guaranteed to be best.

**What does average precision measure?** It summarizes the precision-recall curve and is useful when the positive class is uncommon.

**What is permutation importance?** It estimates how much a chosen evaluation score worsens when a feature is shuffled; it indicates predictive usefulness, not causation.

## Next improvements
- Add cross-validation and threshold tuning based on an explicit cost matrix.
- Add SHAP explanations (with appropriate caveats).
- Add model/data drift monitoring.
- Replace synthetic data with a suitable public dataset for a research-grade extension.
