"""
Transaction Intelligence Lab — B.Tech CSE (AI/ML) portfolio project
Synthetic educational dataset only. Not for real financial decisions.
Run from project root: python src/train.py
"""
from pathlib import Path
import json
import joblib
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns

from sklearn.model_selection import train_test_split
from sklearn.compose import ColumnTransformer
from sklearn.preprocessing import OneHotEncoder, StandardScaler
from sklearn.impute import SimpleImputer
from sklearn.pipeline import Pipeline
from sklearn.ensemble import RandomForestClassifier, HistGradientBoostingClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import (
    classification_report, confusion_matrix, ConfusionMatrixDisplay,
    precision_recall_curve, average_precision_score, roc_auc_score,
    accuracy_score, precision_score, recall_score, f1_score, brier_score_loss
)
from sklearn.inspection import permutation_importance

ROOT = Path(__file__).resolve().parents[1]
DATA = ROOT / "data" / "transactions_synthetic.csv"
OUT = ROOT / "reports"
MODELS = ROOT / "models"
OUT.mkdir(exist_ok=True)
MODELS.mkdir(exist_ok=True)
sns.set_theme(style="whitegrid")

df = pd.read_csv(DATA)
required = ["amount_inr", "hour", "merchant_category", "is_weekend",
            "new_device", "location_mismatch", "failed_attempts", "is_fraud"]
missing = sorted(set(required) - set(df.columns))
if missing:
    raise ValueError(f"Dataset is missing required columns: {missing}")
if df.empty:
    raise ValueError("Dataset is empty.")
df = df.drop_duplicates(subset=["transaction_id"]).copy()
df = df[df["amount_inr"].ge(0)].copy()

target = "is_fraud"
features = ["amount_inr", "hour", "merchant_category", "is_weekend",
            "new_device", "location_mismatch", "failed_attempts"]
X, y = df[features], df[target].astype(int)
X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.20, random_state=42, stratify=y
)

numeric = ["amount_inr", "hour", "is_weekend", "new_device",
           "location_mismatch", "failed_attempts"]
categorical = ["merchant_category"]
preprocessor = ColumnTransformer([
    ("num", Pipeline([("imputer", SimpleImputer(strategy="median")),
                      ("scaler", StandardScaler())]), numeric),
    ("cat", Pipeline([("imputer", SimpleImputer(strategy="most_frequent")),
                      ("onehot", OneHotEncoder(handle_unknown="ignore"))]), categorical)
])

candidates = {
    "Logistic Regression": LogisticRegression(max_iter=1500, class_weight="balanced"),
    "Random Forest": RandomForestClassifier(
        n_estimators=250, min_samples_leaf=3, class_weight="balanced",
        random_state=42, n_jobs=-1
    )
}
results = []
fitted = {}
for name, estimator in candidates.items():
    pipe = Pipeline([("preprocess", preprocessor), ("model", estimator)])
    pipe.fit(X_train, y_train)
    pred = pipe.predict(X_test)
    score = pipe.predict_proba(X_test)[:, 1]
    row = {
        "model": name,
        "accuracy": accuracy_score(y_test, pred),
        "precision": precision_score(y_test, pred, zero_division=0),
        "recall": recall_score(y_test, pred, zero_division=0),
        "f1": f1_score(y_test, pred, zero_division=0),
        "roc_auc": roc_auc_score(y_test, score),
        "average_precision": average_precision_score(y_test, score),
        "brier_score": brier_score_loss(y_test, score)
    }
    results.append(row)
    fitted[name] = (pipe, pred, score)

metrics = pd.DataFrame(results).sort_values("average_precision", ascending=False)
metrics.to_csv(OUT / "model_comparison.csv", index=False)
best_name = metrics.iloc[0]["model"]
best_pipe, best_pred, best_score = fitted[best_name]
joblib.dump(best_pipe, MODELS / "best_model.joblib")

# Model comparison
plt.figure(figsize=(9, 5))
plot_df = metrics.melt(id_vars="model", value_vars=["precision", "recall", "f1", "roc_auc", "average_precision"],
                       var_name="metric", value_name="score")
sns.barplot(data=plot_df, x="metric", y="score", hue="model")
plt.ylim(0, 1)
plt.title("Baseline Model Comparison (Synthetic Test Split)")
plt.tight_layout()
plt.savefig(OUT / "01_model_comparison.png", dpi=160)
plt.close()

# Confusion matrix
disp = ConfusionMatrixDisplay(confusion_matrix(y_test, best_pred), display_labels=["Normal label", "Fraud label"])
disp.plot(values_format="d")
plt.title(f"Confusion Matrix — {best_name}")
plt.tight_layout()
plt.savefig(OUT / "02_confusion_matrix.png", dpi=160)
plt.close()

# Precision-recall curve: useful for imbalanced classification
precision, recall, _ = precision_recall_curve(y_test, best_score)
plt.figure(figsize=(7, 5))
plt.plot(recall, precision)
plt.xlabel("Recall")
plt.ylabel("Precision")
plt.title(f"Precision–Recall Curve — {best_name}")
plt.tight_layout()
plt.savefig(OUT / "03_precision_recall_curve.png", dpi=160)
plt.close()

# Exploratory analysis
category_summary = df.groupby("merchant_category").agg(
    transactions=("transaction_id", "count"),
    fraud_label_rate=("is_fraud", "mean"),
    median_amount_inr=("amount_inr", "median")
).reset_index()
category_summary["fraud_label_rate_pct"] = (category_summary["fraud_label_rate"] * 100).round(2)
category_summary.to_csv(OUT / "category_eda.csv", index=False)

plt.figure(figsize=(8, 5))
sns.barplot(data=category_summary, x="merchant_category", y="fraud_label_rate_pct")
plt.title("Synthetic Fraud-Label Rate by Merchant Category")
plt.ylabel("Fraud-label rate (%)")
plt.xlabel("Merchant category")
plt.xticks(rotation=20)
plt.tight_layout()
plt.savefig(OUT / "04_category_eda.png", dpi=160)
plt.close()

# Permutation importance on held-out data (model-agnostic)
perm = permutation_importance(best_pipe, X_test, y_test, n_repeats=5,
                              random_state=42, scoring="average_precision", n_jobs=-1)
importance = pd.DataFrame({"feature": features, "importance_mean": perm.importances_mean,
                           "importance_std": perm.importances_std}).sort_values("importance_mean", ascending=False)
importance.to_csv(OUT / "permutation_importance.csv", index=False)
plt.figure(figsize=(8, 5))
sns.barplot(data=importance, x="importance_mean", y="feature")
plt.title("Permutation Importance (Average Precision)")
plt.tight_layout()
plt.savefig(OUT / "05_permutation_importance.png", dpi=160)
plt.close()

report = classification_report(y_test, best_pred, zero_division=0)
(OUT / "classification_report.txt").write_text(
    "TRANSACTION INTELLIGENCE LAB — MODEL REPORT\n"
    "Dataset is synthetic; metrics are for demonstration only.\n\n"
    f"Selected baseline by Average Precision: {best_name}\n\n"
    + metrics.to_string(index=False, float_format=lambda v: f"{v:.4f}")
    + "\n\nClassification report:\n" + report
    + "\n\nCaution: these scores do not establish real-world fraud detection ability.\n",
    encoding="utf-8"
)

summary = {
    "rows_after_deduplication": int(len(df)),
    "positive_label_count": int(y.sum()),
    "positive_label_rate_pct": round(float(y.mean() * 100), 3),
    "train_rows": int(len(X_train)),
    "test_rows": int(len(X_test)),
    "selected_baseline": best_name,
    "selection_metric": "average_precision",
    "dataset_type": "synthetic"
}
(OUT / "run_summary.json").write_text(json.dumps(summary, indent=2), encoding="utf-8")

print("\n=== TRANSACTION INTELLIGENCE LAB ===")
print("Rows:", len(df), "| Labelled positives:", int(y.sum()), f"({y.mean()*100:.2f}%)")
print("\nModel comparison:\n", metrics.to_string(index=False, float_format=lambda v: f"{v:.3f}"))
print(f"\nSelected baseline: {best_name} (highest average precision on this split)")
print(f"Reports and charts saved in: {OUT}")
print(f"Serialized model saved in: {MODELS / 'best_model.joblib'}")
